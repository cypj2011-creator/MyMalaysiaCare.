import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";

// Gemini build config
export default defineConfig(({ mode }) => ({
  base: mode === "production" ? "/MyMalaysiaCare/" : "/",
  server: {
    host: "::",
    port: 8080,
  },
  plugins: [react()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
}));
